using UnityEngine;

public class CameraFPS : MonoBehaviour {
    private void Start() {
        Application.targetFrameRate = 60;
    }
}