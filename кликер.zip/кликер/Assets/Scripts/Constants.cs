public class Constants
{
    public readonly string FormatMoney = "F2";

    public readonly string FilePath = UnityEngine.Application.persistentDataPath + "/data.b1in";

    public readonly double DefaultClickStep = 0.2;
}